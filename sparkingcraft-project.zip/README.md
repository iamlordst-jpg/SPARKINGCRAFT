# SparkingCraft (Forge 1.20.1)
Keys (rebind in Controls > SparkingCraft): C charge ki (hold), R ki blast (hold), G signature beam, H ultimate attack,
X flight, V transform up, B transform down, Z vanish behind target, N next fighter.
Commands: /sparking fighter <name>, /sparking form <n>, /sparking refill
