package com.sparkingcraft.item;

import com.sparkingcraft.ModItems;
import com.sparkingcraft.data.KiData;
import com.sparkingcraft.server.Moves;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class DragonBallItem extends Item {
    public final int star;

    public DragonBallItem(int star, Properties props) { super(props); this.star = star; }

    private static boolean hasStar(Player p, int s) {
        for (ItemStack st : p.getInventory().items)
            if (st.getItem() instanceof DragonBallItem d && d.star == s) return true;
        return false;
    }

    private static void consumeStar(Player p, int s) {
        for (ItemStack st : p.getInventory().items)
            if (st.getItem() instanceof DragonBallItem d && d.star == s) { st.shrink(1); return; }
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack self = player.getItemInHand(hand);
        if (level.isClientSide || !(player instanceof ServerPlayer sp)) return InteractionResultHolder.sidedSuccess(self, level.isClientSide);

        for (int s = 1; s <= 7; s++) {
            if (!hasStar(sp, s)) {
                sp.displayClientMessage(Component.literal("You need all 7 Dragon Balls to summon Shenron."), true);
                return InteractionResultHolder.fail(self);
            }
        }
        for (int s = 1; s <= 7; s++) consumeStar(sp, s);

        LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(level);
        if (bolt != null) { bolt.moveTo(sp.position()); bolt.setVisualOnly(true); level.addFreshEntity(bolt); }
        sp.sendSystemMessage(Component.literal("\u00a76\u00a7lSHENRON: \u00a7eYou have gathered the Dragon Balls. Your wish is granted!"));

        switch (level.random.nextInt(3)) {
            case 0 -> {
                sp.setHealth(sp.getMaxHealth());
                KiData.setKi(sp, KiData.MAX_KI);
                sp.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 12000, 2));
                sp.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 12000, 1));
                sp.sendSystemMessage(Component.literal("Wish: Overwhelming power!"));
            }
            case 1 -> {
                ItemStack beans = new ItemStack(ModItems.SENZU.get(), 8);
                if (!sp.getInventory().add(beans)) sp.drop(beans, false);
                sp.sendSystemMessage(Component.literal("Wish: A bag of Senzu Beans!"));
            }
            default -> {
                KiData.setKi(sp, KiData.MAX_KI);
                KiData.setSparking(sp, 2400);
                sp.sendSystemMessage(Component.literal("Wish: Sparking blessing!"));
            }
        }
        Moves.sync(sp);
        return InteractionResultHolder.success(self);
    }
}
