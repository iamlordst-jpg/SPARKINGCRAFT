package com.sparkingcraft.item;

import java.util.List;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

public class DragonRadarItem extends Item {
    public DragonRadarItem(Properties props) { super(props); }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide) {
            List<ItemEntity> balls = level.getEntitiesOfClass(ItemEntity.class, player.getBoundingBox().inflate(256),
                e -> e.getItem().getItem() instanceof DragonBallItem);
            ItemEntity best = null;
            double bd = Double.MAX_VALUE;
            for (ItemEntity e : balls) {
                double d = e.distanceToSqr(player);
                if (d < bd) { bd = d; best = e; }
            }
            if (best == null) {
                player.displayClientMessage(Component.literal("No Dragon Ball signal nearby."), true);
            } else {
                player.displayClientMessage(Component.literal("Dragon Ball detected: " + (int) Math.sqrt(bd) + " blocks away at "
                    + best.blockPosition().getX() + ", " + best.blockPosition().getZ()), true);
            }
            player.getCooldowns().addCooldown(this, 40);
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
