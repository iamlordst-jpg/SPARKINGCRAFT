package com.sparkingcraft.data;

public record Form(String name, double power, double speed, double health, int drain, int color) {}
