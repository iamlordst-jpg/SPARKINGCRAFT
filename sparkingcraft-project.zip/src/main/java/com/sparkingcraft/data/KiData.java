package com.sparkingcraft.data;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.player.Player;

public final class KiData {
    public static final String KEY = "sparkingcraft";
    public static final int MAX_KI = 1000;

    private KiData() {}

    public static CompoundTag tag(Player p) {
        CompoundTag root = p.getPersistentData();
        if (!root.contains(KEY, 10)) root.put(KEY, new CompoundTag());
        return root.getCompound(KEY);
    }

    public static int ki(Player p) {
        CompoundTag t = tag(p);
        return t.contains("ki") ? t.getInt("ki") : MAX_KI;
    }
    public static void setKi(Player p, int v) { tag(p).putInt("ki", Mth.clamp(v, 0, MAX_KI)); }
    public static void addKi(Player p, int d) { setKi(p, ki(p) + d); }

    public static Fighter fighter(Player p) {
        Fighter[] all = Fighter.values();
        return all[Mth.clamp(tag(p).getInt("fighter"), 0, all.length - 1)];
    }
    public static void setFighter(Player p, Fighter f) { tag(p).putInt("fighter", f.ordinal()); tag(p).putInt("form", 0); }

    public static int formIdx(Player p) {
        return Mth.clamp(tag(p).getInt("form"), 0, fighter(p).forms.length - 1);
    }
    public static void setFormIdx(Player p, int i) { tag(p).putInt("form", Mth.clamp(i, 0, fighter(p).forms.length - 1)); }
    public static Form form(Player p) { return fighter(p).forms[formIdx(p)]; }

    public static boolean charging(Player p) { return tag(p).getBoolean("charging"); }
    public static void setCharging(Player p, boolean b) { tag(p).putBoolean("charging", b); }
    public static boolean flying(Player p) { return tag(p).getBoolean("flying"); }
    public static void setFlying(Player p, boolean b) { tag(p).putBoolean("flying", b); }
    public static int sparking(Player p) { return tag(p).getInt("sparking"); }
    public static void setSparking(Player p, int t) { tag(p).putInt("sparking", Math.max(0, t)); }
}
