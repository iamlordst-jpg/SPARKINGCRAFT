package com.sparkingcraft.data;

import net.minecraft.util.Mth;

/** Plain holder for HUD values; safe to load on both sides. */
public final class ClientData {
    public static int ki = KiData.MAX_KI, fighter = 0, form = 0, sparking = 0;
    public static boolean flying = false, charging = false;

    private ClientData() {}

    public static Fighter fighter() {
        return Fighter.values()[Mth.clamp(fighter, 0, Fighter.values().length - 1)];
    }
    public static Form form() {
        Fighter f = fighter();
        return f.forms[Mth.clamp(form, 0, f.forms.length - 1)];
    }
}
