package com.sparkingcraft.data;

public enum Fighter {
    GOKU("Goku", "Kamehameha", "Dragon Fist",
        f("Base", 1, 1, 0, 0, 0xFF9A2E), f("Super Saiyan", 1.5, 1.1, 4, 8, 0xFFE633),
        f("Super Saiyan 2", 1.8, 1.15, 6, 10, 0xFFF066), f("Super Saiyan 3", 2.3, 1.2, 8, 16, 0xFFD700),
        f("Super Saiyan God", 2.6, 1.3, 10, 14, 0xFF3030), f("Super Saiyan Blue", 3.0, 1.4, 12, 18, 0x30B0FF),
        f("Ultra Instinct", 3.6, 1.6, 16, 25, 0xD0DCFF)),
    VEGETA("Vegeta", "Galick Gun", "Final Flash",
        f("Base", 1, 1, 0, 0, 0x3060FF), f("Super Saiyan", 1.5, 1.1, 4, 8, 0xFFE633),
        f("Super Saiyan Blue", 3.0, 1.4, 12, 18, 0x30B0FF), f("Ultra Ego", 3.5, 1.3, 16, 22, 0xA020C0)),
    GOHAN("Gohan", "Masenko", "Father-Son Kamehameha",
        f("Base", 1, 1, 0, 0, 0x9040FF), f("Super Saiyan 2", 1.9, 1.15, 6, 10, 0xFFF066),
        f("Ultimate", 2.5, 1.25, 10, 12, 0xFFFFFF), f("Beast", 3.5, 1.45, 16, 22, 0xF0F0FF)),
    PICCOLO("Piccolo", "Special Beam Cannon", "Light Grenade",
        f("Base", 1, 1, 0, 0, 0x40D040), f("Orange Piccolo", 2.8, 1.35, 14, 18, 0xFF8A00)),
    TRUNKS("Trunks", "Burning Attack", "Heat Dome Attack",
        f("Base", 1, 1, 0, 0, 0x9070FF), f("Super Saiyan", 1.5, 1.1, 4, 8, 0xFFE633),
        f("Super Saiyan Rage", 2.1, 1.2, 8, 14, 0xFFB000)),
    FRIEZA("Frieza", "Death Beam", "Supernova",
        f("Base", 1, 1.05, 0, 0, 0xD0A0FF), f("Full Power", 2.2, 1.25, 8, 12, 0xFFFFFF),
        f("Golden Frieza", 3.0, 1.4, 12, 18, 0xFFD700), f("Black Frieza", 3.3, 1.45, 14, 20, 0x303030)),
    CELL("Cell", "Solar Kamehameha", "Perfect Barrier Burst",
        f("Perfect Cell", 1.4, 1.1, 4, 0, 0x60C060), f("Super Perfect Cell", 2.5, 1.3, 10, 14, 0x90FF90)),
    BUU("Majin Buu", "Planet Burst", "Chocolate Beam",
        f("Majin Buu", 1.2, 1, 6, 0, 0xFF90C0), f("Super Buu", 1.9, 1.15, 8, 10, 0xFF60A0),
        f("Kid Buu", 2.7, 1.4, 12, 16, 0xFF4090)),
    BROLY("Broly", "Eraser Cannon", "Gigantic Meteor",
        f("Base", 1.2, 1, 6, 0, 0x60FF60), f("Legendary Super Saiyan", 3.2, 1.2, 18, 20, 0x80FF80)),
    JIREN("Jiren", "Power Impact", "Meditation Burst",
        f("Base", 1.8, 1.1, 8, 0, 0xFF4040), f("Full Power", 3.4, 1.4, 16, 20, 0xFF2020)),
    BEERUS("Beerus", "Hakai", "Sphere of Destruction",
        f("Base", 2.0, 1.2, 10, 0, 0xB060FF), f("Destroyer Wrath", 3.2, 1.4, 16, 20, 0xFF40FF)),
    HIT("Hit", "Time-Skip Strike", "Time Cage",
        f("Base", 1.4, 1.2, 4, 0, 0x8080A0), f("Full Power", 2.9, 1.5, 12, 16, 0xA0A0FF));

    public final String display, beam1, beam2;
    public final Form[] forms;

    Fighter(String display, String beam1, String beam2, Form... forms) {
        this.display = display; this.beam1 = beam1; this.beam2 = beam2; this.forms = forms;
    }

    private static Form f(String n, double p, double s, double h, int d, int c) {
        return new Form(n, p, s, h, d, c);
    }

    public static Fighter byName(String s) {
        for (Fighter f : values()) if (f.name().equalsIgnoreCase(s)) return f;
        return null;
    }
}
