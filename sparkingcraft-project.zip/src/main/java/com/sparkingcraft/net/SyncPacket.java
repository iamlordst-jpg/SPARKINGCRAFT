package com.sparkingcraft.net;

import com.sparkingcraft.data.ClientData;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraftforge.network.NetworkEvent;

public record SyncPacket(int ki, int fighter, int form, int sparking, boolean flying, boolean charging) {
    public static void enc(SyncPacket p, FriendlyByteBuf b) {
        b.writeInt(p.ki); b.writeInt(p.fighter); b.writeInt(p.form); b.writeInt(p.sparking);
        b.writeBoolean(p.flying); b.writeBoolean(p.charging);
    }
    public static SyncPacket dec(FriendlyByteBuf b) {
        return new SyncPacket(b.readInt(), b.readInt(), b.readInt(), b.readInt(), b.readBoolean(), b.readBoolean());
    }
    public static void handle(SyncPacket p, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> {
            ClientData.ki = p.ki; ClientData.fighter = p.fighter; ClientData.form = p.form;
            ClientData.sparking = p.sparking; ClientData.flying = p.flying; ClientData.charging = p.charging;
        });
        c.setPacketHandled(true);
    }
}
