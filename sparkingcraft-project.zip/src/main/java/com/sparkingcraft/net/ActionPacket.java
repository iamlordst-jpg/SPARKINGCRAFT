package com.sparkingcraft.net;

import com.sparkingcraft.server.Moves;
import java.util.function.Supplier;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraftforge.network.NetworkEvent;

public record ActionPacket(int action, boolean down) {
    public static void enc(ActionPacket p, FriendlyByteBuf b) { b.writeByte(p.action); b.writeBoolean(p.down); }
    public static ActionPacket dec(FriendlyByteBuf b) { return new ActionPacket(b.readByte(), b.readBoolean()); }
    public static void handle(ActionPacket p, Supplier<NetworkEvent.Context> s) {
        NetworkEvent.Context c = s.get();
        c.enqueueWork(() -> {
            ServerPlayer sp = c.getSender();
            if (sp != null) Moves.perform(sp, p.action, p.down);
        });
        c.setPacketHandled(true);
    }
}
