package com.sparkingcraft.net;

import com.sparkingcraft.SparkingCraft;
import net.minecraft.resources.ResourceLocation;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;

public final class Net {
    private static final String V = "1";
    public static final SimpleChannel CH = NetworkRegistry.newSimpleChannel(
        new ResourceLocation(SparkingCraft.MODID, "main"), () -> V, V::equals, V::equals);

    private Net() {}

    public static void register() {
        int id = 0;
        CH.registerMessage(id++, ActionPacket.class, ActionPacket::enc, ActionPacket::dec, ActionPacket::handle);
        CH.registerMessage(id++, SyncPacket.class, SyncPacket::enc, SyncPacket::dec, SyncPacket::handle);
    }
}
