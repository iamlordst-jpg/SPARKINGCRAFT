package com.sparkingcraft.client;

import com.sparkingcraft.SparkingCraft;
import com.sparkingcraft.data.ClientData;
import com.sparkingcraft.data.Fighter;
import com.sparkingcraft.data.Form;
import com.sparkingcraft.data.KiData;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterGuiOverlaysEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.gui.overlay.ForgeGui;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid = SparkingCraft.MODID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public final class ClientModEvents {
    private static final String CAT = "key.categories.sparkingcraft";
    public static final KeyMapping CHARGE = new KeyMapping("key.sparkingcraft.charge", GLFW.GLFW_KEY_C, CAT);
    public static final KeyMapping BLAST = new KeyMapping("key.sparkingcraft.blast", GLFW.GLFW_KEY_R, CAT);
    public static final KeyMapping BEAM1 = new KeyMapping("key.sparkingcraft.beam1", GLFW.GLFW_KEY_G, CAT);
    public static final KeyMapping BEAM2 = new KeyMapping("key.sparkingcraft.beam2", GLFW.GLFW_KEY_H, CAT);
    public static final KeyMapping FLIGHT = new KeyMapping("key.sparkingcraft.flight", GLFW.GLFW_KEY_X, CAT);
    public static final KeyMapping FORM_UP = new KeyMapping("key.sparkingcraft.form_up", GLFW.GLFW_KEY_V, CAT);
    public static final KeyMapping FORM_DOWN = new KeyMapping("key.sparkingcraft.form_down", GLFW.GLFW_KEY_B, CAT);
    public static final KeyMapping VANISH = new KeyMapping("key.sparkingcraft.vanish", GLFW.GLFW_KEY_Z, CAT);
    public static final KeyMapping FIGHTER = new KeyMapping("key.sparkingcraft.fighter", GLFW.GLFW_KEY_N, CAT);

    private ClientModEvents() {}

    @SubscribeEvent
    public static void keys(RegisterKeyMappingsEvent e) {
        e.register(CHARGE); e.register(BLAST); e.register(BEAM1); e.register(BEAM2); e.register(FLIGHT);
        e.register(FORM_UP); e.register(FORM_DOWN); e.register(VANISH); e.register(FIGHTER);
    }

    @SubscribeEvent
    public static void overlays(RegisterGuiOverlaysEvent e) {
        e.registerAboveAll("ki", ClientModEvents::renderHud);
    }

    private static void renderHud(ForgeGui gui, GuiGraphics g, float pt, int w, int h) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        Fighter f = ClientData.fighter();
        Form form = ClientData.form();
        int x = 10, y = h - 56, bw = 110;
        g.fill(x - 1, y - 1, x + bw + 1, y + 9, 0xAA000000);
        g.fill(x, y, x + (int) (bw * ClientData.ki / (float) KiData.MAX_KI), y + 8, 0xFF000000 | form.color());
        g.drawString(mc.font, f.display + " - " + form.name(), x, y - 12, 0xFFFFFF, true);
        g.drawString(mc.font, "KI " + ClientData.ki + (ClientData.charging ? "  (charging)" : "") + (ClientData.flying ? "  (flying)" : ""), x, y + 11, 0xFFFFFF, true);
        if (ClientData.sparking > 0) {
            g.drawString(mc.font, "SPARKING! " + (ClientData.sparking / 20 + 1) + "s", x, y + 22, 0xFFAA00, true);
        }
    }
}
