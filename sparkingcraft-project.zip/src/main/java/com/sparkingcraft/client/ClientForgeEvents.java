package com.sparkingcraft.client;

import com.sparkingcraft.SparkingCraft;
import com.sparkingcraft.net.ActionPacket;
import com.sparkingcraft.net.Net;
import net.minecraft.client.Minecraft;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;

@Mod.EventBusSubscriber(modid = SparkingCraft.MODID, value = Dist.CLIENT)
public final class ClientForgeEvents {
    private static boolean charging = false;

    private ClientForgeEvents() {}

    private static void send(int action, boolean down) { Net.CH.sendToServer(new ActionPacket(action, down)); }

    @SubscribeEvent
    public static void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null) return;

        boolean down = ClientModEvents.CHARGE.isDown() && mc.screen == null;
        if (down != charging) { charging = down; send(0, down); }

        if (mc.screen != null) return;
        if (ClientModEvents.BLAST.isDown()) send(1, true);
        while (ClientModEvents.BEAM1.consumeClick()) send(2, true);
        while (ClientModEvents.BEAM2.consumeClick()) send(8, true);
        while (ClientModEvents.FLIGHT.consumeClick()) send(3, true);
        while (ClientModEvents.FORM_UP.consumeClick()) send(4, true);
        while (ClientModEvents.FORM_DOWN.consumeClick()) send(7, true);
        while (ClientModEvents.VANISH.consumeClick()) send(5, true);
        while (ClientModEvents.FIGHTER.consumeClick()) send(6, true);
    }
}
