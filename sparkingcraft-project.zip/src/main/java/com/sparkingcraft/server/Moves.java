package com.sparkingcraft.server;

import com.sparkingcraft.data.Fighter;
import com.sparkingcraft.data.Form;
import com.sparkingcraft.data.KiData;
import com.sparkingcraft.net.Net;
import com.sparkingcraft.net.SyncPacket;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;
import net.minecraft.commands.arguments.EntityAnchorArgument;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.attributes.Attribute;
import net.minecraft.world.entity.ai.attributes.AttributeInstance;
import net.minecraft.world.entity.ai.attributes.AttributeModifier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.player.Abilities;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.network.PacketDistributor;
import org.joml.Vector3f;

public final class Moves {
    private static final UUID SPEED_ID = UUID.fromString("5c1f0a10-6d3e-4a55-9a41-0b1b7c5e0001");
    private static final UUID HEALTH_ID = UUID.fromString("5c1f0a10-6d3e-4a55-9a41-0b1b7c5e0002");

    private Moves() {}

    public static void perform(ServerPlayer p, int action, boolean down) {
        switch (action) {
            case 0 -> KiData.setCharging(p, down);
            case 1 -> fire(p, 1, 40, 5, 30, 0.5, 0f, 6);
            case 2 -> fire(p, 2, 300, 20, 40, 1.0, 3f, 50);
            case 3 -> { if (down) toggleFlight(p); }
            case 4 -> { if (down) shiftForm(p, 1); }
            case 5 -> { if (down) vanish(p); }
            case 6 -> { if (down) cycleFighter(p); }
            case 7 -> { if (down) shiftForm(p, -1); }
            case 8 -> fire(p, 8, 450, 30, 28, 1.8, 5f, 90);
            default -> {}
        }
        sync(p);
    }

    public static double damageMult(ServerPlayer p) {
        return KiData.form(p).power() * (KiData.sparking(p) > 0 ? 1.5 : 1.0);
    }

    public static Vector3f rgb(int c) {
        return new Vector3f(((c >> 16) & 255) / 255f, ((c >> 8) & 255) / 255f, (c & 255) / 255f);
    }

    public static void sync(ServerPlayer p) {
        Net.CH.send(PacketDistributor.PLAYER.with(() -> p), new SyncPacket(
            KiData.ki(p), KiData.fighter(p).ordinal(), KiData.formIdx(p),
            KiData.sparking(p), KiData.flying(p), KiData.charging(p)));
    }

    private static boolean onCooldown(ServerPlayer p, int slot) {
        return p.level().getGameTime() < KiData.tag(p).getLong("cd" + slot);
    }

    private static void msg(ServerPlayer p, String s) { p.displayClientMessage(Component.literal(s), true); }

    /** Hit-scan ki attack: beam of particles that damages everything along the line and explodes at the end. */
    private static void fire(ServerPlayer p, int slot, int cost, double dmg, double range, double radius, float blast, int cd) {
        if (onCooldown(p, slot)) return;
        if (KiData.ki(p) < cost) { msg(p, "Not enough ki!"); return; }
        KiData.addKi(p, -cost);
        KiData.tag(p).putLong("cd" + slot, p.level().getGameTime() + cd);

        Fighter f = KiData.fighter(p);
        Form form = KiData.form(p);
        if (slot == 2) msg(p, f.beam1 + "!!");
        else if (slot == 8) msg(p, f.beam2 + "!!");

        ServerLevel lvl = p.serverLevel();
        Vec3 dir = p.getLookAngle().normalize();
        Vec3 start = p.getEyePosition().add(dir.scale(1.0)).add(0, -0.3, 0);
        Vec3 end = start.add(dir.scale(range));
        Set<LivingEntity> hit = new HashSet<>();
        DustParticleOptions dust = new DustParticleOptions(rgb(form.color()), (float) Math.max(1.0, radius * 1.4));

        for (double t = 0; t <= range; t += 0.5) {
            Vec3 pos = start.add(dir.scale(t));
            BlockPos bp = BlockPos.containing(pos);
            if (!lvl.getBlockState(bp).getCollisionShape(lvl, bp).isEmpty()) { end = pos; break; }
            lvl.sendParticles(dust, pos.x, pos.y, pos.z, 2, radius * 0.15, radius * 0.15, radius * 0.15, 0);
            if (slot != 1) lvl.sendParticles(ParticleTypes.END_ROD, pos.x, pos.y, pos.z, 1, 0, 0, 0, 0.01);
            AABB box = new AABB(pos, pos).inflate(radius);
            for (LivingEntity e : lvl.getEntitiesOfClass(LivingEntity.class, box, x -> x != p && x.isAlive())) {
                if (hit.add(e)) {
                    e.hurt(p.damageSources().playerAttack(p), (float) dmg);
                    e.push(dir.x * 1.2, 0.35, dir.z * 1.2);
                    e.hurtMarked = true;
                }
            }
        }
        lvl.playSound(null, p.blockPosition(), slot == 1 ? SoundEvents.FIREWORK_ROCKET_BLAST : SoundEvents.GENERIC_EXPLODE,
            SoundSource.PLAYERS, 1f, slot == 1 ? 1.4f : 0.8f);
        if (blast > 0 && end.distanceTo(p.getEyePosition()) > 6) {
            lvl.explode(p, end.x, end.y, end.z, blast, Level.ExplosionInteraction.MOB);
        }
    }

    public static void toggleFlight(ServerPlayer p) {
        boolean on = !KiData.flying(p);
        if (on && KiData.ki(p) < 50) { msg(p, "Not enough ki to fly!"); return; }
        setFlight(p, on);
        msg(p, on ? "Flight: ON" : "Flight: OFF");
    }

    public static void setFlight(ServerPlayer p, boolean on) {
        KiData.setFlying(p, on);
        Abilities ab = p.getAbilities();
        if (on) {
            ab.mayfly = true;
            ab.flying = true;
        } else if (!p.isCreative() && !p.isSpectator()) {
            ab.mayfly = false;
            ab.flying = false;
        }
        ab.setFlyingSpeed(on ? (float) (0.06 * Math.max(1.0, KiData.form(p).speed()) * 1.5) : 0.05f);
        p.onUpdateAbilities();
    }

    public static void shiftForm(ServerPlayer p, int d) {
        Fighter f = KiData.fighter(p);
        int idx = KiData.formIdx(p) + d;
        if (idx < 0) { msg(p, "Already in base form."); return; }
        if (idx >= f.forms.length) { msg(p, "No higher form for " + f.display + "."); return; }
        if (d > 0 && KiData.ki(p) < 200) { msg(p, "Not enough ki to transform!"); return; }
        KiData.setFormIdx(p, idx);
        applyForm(p);
        Form form = f.forms[idx];
        p.serverLevel().sendParticles(new DustParticleOptions(rgb(form.color()), 2f), p.getX(), p.getY() + 1, p.getZ(), 80, 0.6, 1.0, 0.6, 0.05);
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.LIGHTNING_BOLT_THUNDER, SoundSource.PLAYERS, 0.6f, 1.5f);
        msg(p, f.display + " - " + form.name());
    }

    public static void cycleFighter(ServerPlayer p) {
        Fighter[] all = Fighter.values();
        Fighter next = all[(KiData.fighter(p).ordinal() + 1) % all.length];
        KiData.setFighter(p, next);
        applyForm(p);
        msg(p, "Fighter: " + next.display);
    }

    public static void applyForm(ServerPlayer p) {
        Form f = KiData.form(p);
        mod(p, Attributes.MOVEMENT_SPEED, SPEED_ID, "sparking_speed", f.speed() - 1.0, AttributeModifier.Operation.MULTIPLY_TOTAL);
        mod(p, Attributes.MAX_HEALTH, HEALTH_ID, "sparking_health", f.health(), AttributeModifier.Operation.ADDITION);
        if (p.getHealth() > p.getMaxHealth()) p.setHealth(p.getMaxHealth());
    }

    private static void mod(ServerPlayer p, Attribute a, UUID id, String n, double amt, AttributeModifier.Operation op) {
        AttributeInstance inst = p.getAttribute(a);
        if (inst == null) return;
        inst.removeModifier(id);
        if (amt != 0) inst.addPermanentModifier(new AttributeModifier(id, n, amt, op));
    }

    /** Teleports behind the target you're looking at. */
    private static void vanish(ServerPlayer p) {
        if (onCooldown(p, 5)) return;
        if (KiData.ki(p) < 100) { msg(p, "Not enough ki!"); return; }
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        AABB box = p.getBoundingBox().expandTowards(look.scale(24)).inflate(2);
        LivingEntity best = null;
        double bd = Double.MAX_VALUE;
        for (LivingEntity e : p.level().getEntitiesOfClass(LivingEntity.class, box, x -> x != p && x.isAlive())) {
            Vec3 to = e.getEyePosition().subtract(eye);
            if (to.normalize().dot(look) < 0.85) continue;
            double d = to.lengthSqr();
            if (d < bd) { bd = d; best = e; }
        }
        if (best == null) { msg(p, "No target to vanish behind."); return; }
        KiData.addKi(p, -100);
        KiData.tag(p).putLong("cd5", p.level().getGameTime() + 30);
        p.serverLevel().sendParticles(ParticleTypes.CLOUD, p.getX(), p.getY() + 1, p.getZ(), 25, 0.3, 0.6, 0.3, 0.05);
        Vec3 back = best.getLookAngle().scale(-1.8);
        p.teleportTo(best.getX() + back.x, best.getY(), best.getZ() + back.z);
        p.lookAt(EntityAnchorArgument.Anchor.EYES, best.getEyePosition());
        p.serverLevel().playSound(null, p.blockPosition(), SoundEvents.ENDERMAN_TELEPORT, SoundSource.PLAYERS, 1f, 1.6f);
    }
}
