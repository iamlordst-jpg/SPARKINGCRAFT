package com.sparkingcraft.server;

import com.mojang.brigadier.arguments.IntegerArgumentType;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.sparkingcraft.ModItems;
import com.sparkingcraft.data.Fighter;
import com.sparkingcraft.data.Form;
import com.sparkingcraft.data.KiData;
import java.util.Arrays;
import net.minecraft.commands.Commands;
import net.minecraft.commands.SharedSuggestionProvider;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.game.ClientboundSetTitleTextPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.event.RegisterCommandsEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.LivingDropsEvent;
import net.minecraftforge.event.entity.living.LivingHurtEvent;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;

public class ServerEvents {

    @SubscribeEvent
    public void onTick(TickEvent.PlayerTickEvent e) {
        if (e.phase != TickEvent.Phase.END || e.player.level().isClientSide || !(e.player instanceof ServerPlayer p)) return;
        int tick = p.tickCount;
        Form form = KiData.form(p);

        if (KiData.charging(p)) KiData.addKi(p, 10);

        int sp = KiData.sparking(p);
        if (sp > 0) {
            KiData.setSparking(p, sp - 1);
            if (sp == 1) p.displayClientMessage(Component.literal("Sparking Mode ended."), true);
        }

        if (tick % 20 == 0) {
            KiData.addKi(p, 15 + (sp > 0 ? 30 : 0));
            int drain = form.drain() + (KiData.flying(p) ? 8 : 0);
            if (drain > 0 && !KiData.charging(p)) KiData.addKi(p, -drain);
            if (KiData.ki(p) <= 0) {
                if (KiData.flying(p)) { Moves.setFlight(p, false); p.displayClientMessage(Component.literal("Out of ki!"), true); }
                if (KiData.formIdx(p) > 0) { KiData.setFormIdx(p, 0); Moves.applyForm(p); p.displayClientMessage(Component.literal("Reverted to base form."), true); }
            }
            if (sp > 0) {
                p.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 1, false, false));
                p.addEffect(new MobEffectInstance(MobEffects.REGENERATION, 40, 1, false, false));
            }
        }

        if (tick % 3 == 0 && (KiData.charging(p) || KiData.formIdx(p) > 0 || sp > 0)) {
            ServerLevel lvl = p.serverLevel();
            lvl.sendParticles(new DustParticleOptions(Moves.rgb(form.color()), 1.3f), p.getX(), p.getY() + 1, p.getZ(), 6, 0.4, 0.8, 0.4, 0);
            if (sp > 0) lvl.sendParticles(ParticleTypes.ELECTRIC_SPARK, p.getX(), p.getY() + 1, p.getZ(), 4, 0.5, 0.9, 0.5, 0.1);
        }

        if (tick % 5 == 0) Moves.sync(p);
    }

    @SubscribeEvent
    public void onHurt(LivingHurtEvent e) {
        if (e.getSource().getEntity() instanceof ServerPlayer atk) {
            e.setAmount(e.getAmount() * (float) Moves.damageMult(atk));
        }
        if (e.getEntity() instanceof ServerPlayer v) {
            float after = v.getHealth() - e.getAmount();
            long now = v.level().getGameTime();
            if (KiData.sparking(v) <= 0 && after > 0 && after <= v.getMaxHealth() * 0.3f
                && now >= KiData.tag(v).getLong("sparkCd")) {
                KiData.setSparking(v, 600);
                KiData.setKi(v, KiData.MAX_KI);
                KiData.tag(v).putLong("sparkCd", now + 6000);
                v.connection.send(new ClientboundSetTitleTextPacket(Component.literal("\u00a76\u00a7lSPARKING!")));
                Moves.sync(v);
            }
        }
    }

    @SubscribeEvent
    public void onDrops(LivingDropsEvent e) {
        if (e.getEntity() instanceof Monster && e.getSource().getEntity() instanceof ServerPlayer
            && e.getEntity().getRandom().nextFloat() < 0.02f) {
            int i = e.getEntity().getRandom().nextInt(7);
            e.getDrops().add(new ItemEntity(e.getEntity().level(), e.getEntity().getX(), e.getEntity().getY(), e.getEntity().getZ(),
                new ItemStack(ModItems.DRAGON_BALLS.get(i).get())));
        }
    }

    @SubscribeEvent
    public void onClone(PlayerEvent.Clone e) {
        CompoundTag old = e.getOriginal().getPersistentData().getCompound(KiData.KEY).copy();
        old.putBoolean("flying", false);
        old.putBoolean("charging", false);
        old.putInt("sparking", 0);
        if (e.isWasDeath()) { old.putInt("form", 0); old.putInt("ki", KiData.MAX_KI); }
        e.getEntity().getPersistentData().put(KiData.KEY, old);
    }

    @SubscribeEvent
    public void onLogin(PlayerEvent.PlayerLoggedInEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            KiData.setFlying(p, false);
            KiData.setCharging(p, false);
            Moves.applyForm(p);
            Moves.sync(p);
        }
    }

    @SubscribeEvent
    public void onRespawn(PlayerEvent.PlayerRespawnEvent e) {
        if (e.getEntity() instanceof ServerPlayer p) {
            Moves.applyForm(p);
            Moves.sync(p);
        }
    }

    @SubscribeEvent
    public void onCommands(RegisterCommandsEvent e) {
        e.getDispatcher().register(Commands.literal("sparking")
            .then(Commands.literal("fighter").then(Commands.argument("name", StringArgumentType.word())
                .suggests((c, b) -> SharedSuggestionProvider.suggest(Arrays.stream(Fighter.values()).map(x -> x.name().toLowerCase()), b))
                .executes(c -> {
                    ServerPlayer p = c.getSource().getPlayerOrException();
                    Fighter f = Fighter.byName(StringArgumentType.getString(c, "name"));
                    if (f == null) { p.displayClientMessage(Component.literal("Unknown fighter."), true); return 0; }
                    KiData.setFighter(p, f);
                    Moves.applyForm(p);
                    Moves.sync(p);
                    p.displayClientMessage(Component.literal("Fighter: " + f.display), true);
                    return 1;
                })))
            .then(Commands.literal("form").then(Commands.argument("n", IntegerArgumentType.integer(0, 9)).executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                KiData.setFormIdx(p, IntegerArgumentType.getInteger(c, "n"));
                Moves.applyForm(p);
                Moves.sync(p);
                return 1;
            })))
            .then(Commands.literal("refill").executes(c -> {
                ServerPlayer p = c.getSource().getPlayerOrException();
                KiData.setKi(p, KiData.MAX_KI);
                Moves.sync(p);
                return 1;
            })));
    }
}
