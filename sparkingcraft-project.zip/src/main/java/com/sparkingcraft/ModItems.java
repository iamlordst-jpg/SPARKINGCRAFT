package com.sparkingcraft;

import com.sparkingcraft.item.DragonBallItem;
import com.sparkingcraft.item.DragonRadarItem;
import com.sparkingcraft.item.SenzuBeanItem;
import java.util.ArrayList;
import java.util.List;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, SparkingCraft.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, SparkingCraft.MODID);

    public static final List<RegistryObject<Item>> DRAGON_BALLS = new ArrayList<>();
    public static final RegistryObject<Item> SENZU = ITEMS.register("senzu_bean", () -> new SenzuBeanItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> RADAR = ITEMS.register("dragon_radar", () -> new DragonRadarItem(new Item.Properties().stacksTo(1)));

    static {
        for (int i = 1; i <= 7; i++) {
            final int star = i;
            DRAGON_BALLS.add(ITEMS.register("dragon_ball_" + i, () -> new DragonBallItem(star, new Item.Properties().stacksTo(1))));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () ->
        CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.sparkingcraft"))
            .icon(() -> new ItemStack(SENZU.get()))
            .displayItems((params, out) -> ITEMS.getEntries().forEach(e -> out.accept(e.get())))
            .build());

    private ModItems() {}
}
